# Prompt for Claude Design

Redesign the AgentOnTrack frontend in the attached folder, in the style of Linear: quiet neutral charcoal, dense and crisp, one accent, keyboard-first, restrained motion. Dynamic yet simple. Premium software for people who run AI coding agents all day, not a prototype.

**What AgentOnTrack is.** A local-first control layer for AI coding agents (Claude Code, Codex, others). The person sets a goal, approves consequential actions, and independent checks decide when work is done; evidence is recorded. The site (`web/`, Next.js static export) explains it and runs an invitation-only early-access programme: a popup application form about five seconds after arriving, an Early access button, a sign-in page, an invitation page, an administrator review page, an account page, a gated install page. The app (`dashboard/`, Vite + React) is the working tool: projects, a workspace (files, agent feed and composer, approvals, handoffs, worktrees), sessions, plans, agents, approvals, safety, records, analytics, settings, and a phone layout.

**Keep, exactly.**
- The file structure, component names, exports and props. Add files if you need to; do not rename or remove.
- Every `data-testid` (listed in `TESTIDS.md`), every role and accessible name, and the visible headings, labels and button texts the tests in `reference/e2e/` look for.
- The shared token block `/* tokens:start */ … /* tokens:end */`: it must be byte-identical in `web/app/globals.css` and `dashboard/src/styles.css`.
- Plain React and plain CSS. No Tailwind, Radix, CSS-in-JS, icon libraries or new dependencies. No external requests: fonts only from `fonts/` (SIL OFL), icons inline SVG.
- Dark (default) and light (`html[data-theme='light']`), both WCAG 2.2 AA (4.5:1 text contrast, visible focus, dialogs that trap and return focus, 28px+ targets, 44px on the phone layout).
- All `transition`/`animation` rules inside `@media (prefers-reduced-motion: no-preference)`. Motion carries state; nothing loops decoratively.
- No horizontal scroll from 360px up. Under 800px the dashboard shows one pane at a time with a bottom tab bar.
- The dashboard CSP: no inline `<script>`, fonts from self only.
- The copy's honesty: keep every "NOT TESTED", "experimental", "Demo data", "invented data" label and every sentence about what the product does not do. Never add "first", "only", "novel", "tamper-proof", "guaranteed", testimonials, third-party logos or adoption numbers.
- Do not edit `web/lib/`, `dashboard/src/api.ts`, `accounts*.ts`, `*-backend.ts`, `demo.ts`, `metrics.ts`, `*-model.ts`, `dictation-core.ts`, or any test.

**Design the rest freely:** the token values (surfaces, borders, text, the single accent), type scale and spacing, the rail and top bar, cards, lists and tables, badges, forms, dialogs, toasts, empty states, charts' look (they are hand-rolled SVG in `charts.tsx`), the landing page's structure and sections, the early-access dialog, the sign-in and invitation pages, the administrator table, the phone layout. The landing page shows the product itself: there is a tour frame (`web/app/tour.tsx`) and a "closer look" strip that take real screenshots from `web/public/shots/` (poster `projects.png`, `tour.webm`, `project-workflow.png`, `workspace.png`, `approvals.png`); design around those slots, do not replace them with illustrations.

**Deliver** the same folder with the files changed in place, plus `CHANGES.md`: what changed, why, and anything you could not do within these rules.
