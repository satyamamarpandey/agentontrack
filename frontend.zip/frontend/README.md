# AgentOnTrack frontend: staging copy for the redesign

A copy of every frontend file, taken from the repository on 2026-11-10, for redesigning with Claude Design. It is not wired into the build: the live sources stay in `apps/web` and `apps/dashboard`. When the redesign is in place here, say so, and the files are merged back, built and tested; then this folder is deleted. The folder is ignored by git.

## What is here, and where it goes back

| Here | Back to | What it is |
|---|---|---|
| `web/` | `apps/web/` | The public site: Next.js 16, static export (`output: 'export'`), React 19, plain CSS. `app/` holds the pages (one folder per route), `app/globals.css` the design system, `app/fonts/` the bundled fonts, `app/ui/` the dialog, toast and icons, `app/early-access/` the application form and popup, `lib/` the data and Firebase code (not design). |
| `dashboard/` | `apps/dashboard/` | The operational app: Vite 8, React 19, plain CSS. `src/styles.css` is the design system, `src/App.tsx` the shell (rail, top bar, screens), `src/entry.tsx` the welcome and connect pages, `src/workspace.tsx`, `src/sessions.tsx`, `src/projects.tsx`, `src/plan.tsx`, `src/agents.tsx`, `src/mobile.tsx` the phone layout (`src/mobile.css`), `src/human.tsx` the dialog and confirmation flow, `src/palette.tsx` the command palette, `src/charts.tsx` the SVG charts, `src/icons.tsx` the icon set. |
| `reference/DESIGN.md` | read only | The interface design notes as they stand. |
| `reference/AGENTS.md` | read only | Wording rules the whole project follows (no "first/only/novel/tamper-proof", nothing claimed without evidence). |
| `reference/e2e/` | read only | The browser tests. They find things by `data-testid`, by role and accessible name, and by visible text. |
| `reference/build-pages.mjs` | read only | How the site is built: it refuses to publish source maps, private paths or keys, and expects `index.html`, `install/`, `dashboard/`, `install.sh`, `install.ps1`. |
| `TESTIDS.md` | — | Every `data-testid` in the frontend, by file. Keep them all. |

## Contracts that must survive the redesign

- **File structure, exports and props.** Same files, same component names and props. New files are fine; renaming or removing existing ones is not.
- **`data-testid`s** (see `TESTIDS.md`), **roles**, **accessible names** and the **visible headings, labels and button texts** the tests use. When in doubt, search `reference/e2e/` for the string.
- **The shared token block.** `web/app/globals.css` and `dashboard/src/styles.css` both contain `/* tokens:start */ … /* tokens:end */`. The two blocks must stay byte-identical (a unit test checks). Change the values in both.
- **Plain CSS and React.** No Tailwind, Radix, CSS-in-JS, icon packs or any new dependency. No external requests of any kind: fonts come from `fonts/` (SIL OFL files only), icons are inline SVG. A test fails on any request to a third party.
- **Themes.** Dark is default; light is `html[data-theme='light']`. Both must meet WCAG 2.2 AA contrast (4.5:1 for text, 3:1 for large text and controls). axe runs on every page in both themes.
- **Motion.** Every `transition` and `animation` sits inside `@media (prefers-reduced-motion: no-preference)` (a unit test checks). Nothing animates on its own except state (a live dot, a progress bar). Keep the scroll-linked reveal inside `@supports (animation-timeline: view())`.
- **Accessibility.** Dialogs trap focus, close on Escape and return focus; the page behind is `inert`. Visible focus rings. Touch targets 28px or more (44px on the phone layout). Skip link. Landmarks.
- **Responsive.** Desktop, laptop, tablet and phone down to 360px with no horizontal scroll. The dashboard switches to one pane at a time under 800px; the workspace has a bottom tab bar there.
- **Content Security Policy** in `dashboard/index.html`: `default-src 'none'`, no inline scripts, `font-src 'self'`. Inline `style` attributes are allowed; inline `<script>` is not.
- **Words.** Copy states facts. Keep every "NOT TESTED", "experimental", "Demo data", "invented data", "scripted model" label and every sentence that says what the product does not do. Never add "first", "only", "novel", "tamper-proof", "guaranteed", testimonials, logos of other companies, or adoption numbers.
- **Do not touch** `web/lib/` (data, validation, Firebase), anything under `dashboard/src/*-backend.ts`, `accounts*.ts`, `api.ts`, `demo.ts`, `metrics.ts`, `*-model.ts`, `dictation-core.ts`, or the tests.

## Direction

Linear-like: quiet neutral charcoal surfaces, 1px borders instead of shadows, 13–14px Inter in the app, one teal accent used only for focus, selection and the primary action, dense lists, a keyboard-first feel (Ctrl/Cmd K palette, "G then a letter" jumps), short easing (120–280 ms), nothing decorative. The site matches the app: same tokens, sans only, large real screenshots of the product rather than illustrations. Dynamic yet simple.

## How it is merged back

1. `frontend/web/*` is copied over `apps/web/*` and `frontend/dashboard/*` over `apps/dashboard/*` (nothing is deleted on the repository side unless `CHANGES.md` says a file was removed on purpose).
2. `pnpm lint`, `pnpm test` (includes the token and motion checks), `pnpm build`, `pnpm build:pages`.
3. Browser suites on Chromium, Firefox, WebKit, Edge and the phone profile; the Firebase-emulator suites; screenshots and the tour recording are captured again from the result.
4. `frontend/` is deleted.
