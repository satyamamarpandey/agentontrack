'use client';
import { useEffect, useState, type ReactNode } from 'react';
import { Modal } from '../ui/modal';
import { EarlyAccessForm } from './form';
import { SIGNED_IN_FLAG } from '../../lib/accounts-config';
import { appliedBefore, POPUP_DELAY_MS, rememberSeen, wasSeen } from '../../lib/early-access';

const OPEN = 'aot-ea-open';
/** Any button anywhere opens the one dialog the host renders. */
export const openEarlyAccess = () => window.dispatchEvent(new Event(OPEN));

export function EarlyAccessButton({ className = 'btn primary', children, testId }: { className?: string; children: ReactNode; testId?: string }) {
  // Safari does not focus a clicked button, so focus it first: the dialog returns focus to whatever opened it.
  return <button type="button" className={className} onClick={(e) => { e.currentTarget.focus(); openEarlyAccess(); }} {...(testId ? { 'data-testid': testId } : {})}>{children}</button>;
}

/** Mounted once, in the layout. Renders nothing until asked. */
export function EarlyAccessHost() {
  const [open, setOpen] = useState(false);
  useEffect(() => {
    const on = () => { rememberSeen(); setOpen(true); };
    window.addEventListener(OPEN, on);
    return () => window.removeEventListener(OPEN, on);
  }, []);
  if (!open) return null;
  return (
    <Modal label="Early access application" onClose={() => { rememberSeen(); setOpen(false); }} testId="early-access-dialog">
      <EarlyAccessForm source="popup" />
    </Modal>
  );
}

/**
 * On the home page only: opens the application about five seconds after arrival, once per browser session, and never for someone who already
 * applied here, is signed in, or is busy typing. Dismissing it is remembered for the session.
 */
export function EarlyAccessAutoPopup({ delayMs = POPUP_DELAY_MS }: { delayMs?: number }) {
  useEffect(() => {
    let signedIn = false;
    try { signedIn = localStorage.getItem(SIGNED_IN_FLAG) === '1'; } catch { /* storage may be blocked */ }
    const armed = !(wasSeen() || appliedBefore() || signedIn);
    document.documentElement.dataset.eaPopup = armed ? 'armed' : 'off'; // visible to tests and to anyone debugging why it did or did not appear
    if (!armed) return undefined;
    const t = setTimeout(() => {
      const el = document.activeElement;
      if (el && /^(INPUT|TEXTAREA|SELECT)$/.test(el.tagName)) return; // they are doing something; do not interrupt
      if (document.querySelector('[role="dialog"]')) return;
      openEarlyAccess();
    }, delayMs);
    return () => clearTimeout(t);
  }, [delayMs]);
  return null;
}
